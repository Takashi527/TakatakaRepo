module.exports = {
  index: function(params, callback) {
    callback();
  },
  regexp: function(params, callback) {
    callback();
  }
};
