if (typeof define !== 'function') {
  var define = require('amdefine')(module);
}

define(function(require) {

  var RendrBase = require('rendr/shared/base/collection');

  return RendrBase.extend({});

});
