var _ = require('underscore'),
    Backbone = require('backbone'),
    syncer = require('../syncer'),
    isServer = (typeof window === 'undefined');

if (!isServer) {
  Backbone.$ = window.$ || require('jquery');
}

var BaseModel = Backbone.Model.extend({

  constructor: function(models, options) {
    // Capture the options as instance variable.
    this.options = options || {};

    // Store a reference to the app instance.
    this.app = this.options.app;

    if (!this.app && this.options.collection) {
      this.app = this.options.collection.app;
    }

    Backbone.Model.apply(this, arguments);

    this.on('change', this.store, this);
  },

  /**
   * Idempotent parse
   */
  parse: function(resp) {
    if (resp != null && this.jsonKey) {
      return resp[this.jsonKey] || resp;
    } else {
      return resp;
    }
  },

  /**
   * Instance method to store in the modelStore.
   */
  store: function() {
    this.app.fetcher.modelStore.set(this);
  }
});

/**
 * Mix-in the `syncer`, shared between `BaseModel` and `BaseCollection`, which
 * encapsulates logic for fetching data from the API.
 */
_.extend(BaseModel.prototype, syncer);

module.exports = BaseModel;
