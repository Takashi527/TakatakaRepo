var _ = require('underscore'),
    Super = require('./memory_store');

module.exports = CollectionStore;

function CollectionStore() {
  Super.apply(this, arguments);
}

/**
 * Set up inheritance.
 */
CollectionStore.prototype = Object.create(Super.prototype);
CollectionStore.prototype.constructor = CollectionStore;

CollectionStore.prototype.set = function(collection, params) {
  var data, idAttribute, key;
  params = params || collection.params;
  key = this._getStoreKey(this.modelUtils.modelName(collection.constructor), params);
  idAttribute = collection.model.prototype.idAttribute;
  data = {
    ids: collection.pluck(idAttribute),
    meta: collection.meta,
    params: collection.params
  };
  return Super.prototype.set.call(this, key, data, null);
};

/**
 * Returns an array of model ids.
 */
CollectionStore.prototype.get = function(collectionName, params, callback) {
  var _collectionStore = this;
  /**
   * Kind of jank-sauce. Always merge in the default
   * params for the given collection.
   */
  if (typeof callback == 'function') {
    this.modelUtils.getCollectionConstructor(collectionName, function(Collection) {
      callback(get.call(_collectionStore, collectionName, params, Collection));
    });
    return;
  } else {
    var Collection = this.modelUtils.getCollectionConstructor(collectionName);
    return get.call(this, collectionName, params, Collection);
  }

  function get(collectionName, params, Collection) {
    var key;
    params = _.clone(params || {});
    params = _.defaults(params, Collection.prototype.defaultParams);
    key = this._getStoreKey(collectionName, params);
    return Super.prototype.get.call(this, key);
  }
};

CollectionStore.prototype._formatKey = function(key) {
  return Super.prototype._formatKey.call(this, "_cs:" + key);
};

CollectionStore.prototype._getStoreKey = function(collectionName, params) {
  var underscored = this.modelUtils.underscorize(collectionName);
  return underscored + ":" + JSON.stringify(sortParams(params));
}

function sortParams(params) {
  var sorted = {};
  _.chain(params).keys().sort().forEach(function(key) {
    sorted[key] = params[key];
  });
  return sorted;
}
