module.exports = {
  index: function(params, callback) {
    callback();
  }
};
