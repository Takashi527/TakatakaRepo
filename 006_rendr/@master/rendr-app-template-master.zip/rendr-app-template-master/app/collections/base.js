var RendrBase = require('rendr/shared/base/collection');

module.exports = RendrBase.extend({});
