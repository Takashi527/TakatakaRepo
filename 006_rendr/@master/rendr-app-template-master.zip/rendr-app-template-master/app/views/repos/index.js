var BaseView = require('../base');

module.exports = BaseView.extend({
  className: 'repos_index_view'
});
module.exports.id = 'repos/index';
