var BaseView = require('../base');

module.exports = BaseView.extend({
  className: 'users_index_view'
});
module.exports.id = 'users/index';
